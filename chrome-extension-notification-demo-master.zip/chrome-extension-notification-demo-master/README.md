## What is the repository?

A very basic Chrome extension that display a notification.
The source code of the post https://medium.com/@moshfeu/notifications-in-chrome-extension-50aac17b3b7d?sk=9253f1ba46cf9bc89a56578582b3ad8e.


## How to run it locally?

Clone the repository and follow the [docs](https://developer.chrome.com/extensions/getstarted)

## Questions? Notes?

Tweet me [@moshfeu](https://twitter.com/moshfeu) or open an issue
